#include<iostream>
int yylex();
int main(){
  yylex();
  return 0;
}
